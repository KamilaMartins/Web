<?php
App::uses('AppController', 'Controller');
/**
 * Exames Controller
 *
 * @property Exame $Exame
 * @property PaginatorComponent $Paginator
 */
class AdminsController extends AppController {

	public function index() {
	}
}

